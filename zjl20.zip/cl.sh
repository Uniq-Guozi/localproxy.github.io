#!/system/bin/sh
if [[ `ps|grep tiny|grep -v grep` != "" ]]
then  echo "¤核心检测 :  ✅ 已运行Tiny"
else echo "¤核心检测 :  ❌ 未运行Tiny";fi