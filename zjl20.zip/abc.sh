if [[ `ps|grep tiny|grep -v grep` != "" ]]
then  echo "a"
else echo "b";fi