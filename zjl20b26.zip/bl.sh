#!/system/bin/sh
DIR=/data/data/com.android.TyFlow/files

$DIR/tiny -k $DIR/tiny.pid
#echo "❌ 已停止Tiny" 
killall -9 tiny >/dev/null 2>&1
if [[ `ps|grep tiny|grep -v grep` != "" ]]
then  echo "¤核心检测 :  ✅ Tiny停止失败"
else echo "¤核心检测 :  ❌ 未运行Tiny";fi
