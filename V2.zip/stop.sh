pkill ss-local
pkill pdnsd
pkill gost
pkill redsocks2
iptables -tmangle -P FORWARD ACCEPT
iptables -t mangle -F
iptables -t nat -F
iptables -t filter -F
ip rule del fwmark 0x6688 table 251 2>&-
ip route del local 0.0.0.0/0 dev lo table 251
JDIR='/data/data/com.android.TyFlow/files'
$JDIR/check.sh