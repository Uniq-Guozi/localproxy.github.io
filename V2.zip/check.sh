echo "  "
if [[ `ps|grep -i ss-local` != "" ]]
then
echo " ● 已启用 ss-local"
else
echo " ○ 已停用 ss-local"
fi
echo "  "
if [[ `ps|grep -i pdnsd` != "" ]]
then
echo " ● 已启用 pdnsd"
else
echo " ○ 已停用 pdnsd"
fi
echo "  "
if [[ `ps|grep -i gost` != "" ]]
then
echo " ● 已启用 gost"
else
echo " ○ 已停用 gost"
fi
echo "  "
if [[ `ps|grep -i redsocks2` != "" ]]
then
echo " ● 已启用 redsocks2"
else
echo " ○ 已停用 redsocks2"
fi
echo ""
echo "→ nat ←"
iptables -tnat -S OUTPUT
echo ""
iptables -tnat -S PREROUTING
echo ""
echo "→ mangle ←"
iptables -tmangle -S OUTPUT
echo ""
iptables -tmangle -S PREROUTING
echo ""
iptables -tmangle -S FORWARD
echo ""
ip rule
ip route