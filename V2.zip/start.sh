cd "${0%/*}"
./stopp.sh

iptables -tmangle -I OUTPUT -o rmnet+ -j DROP
iptables -tmangle -I OUTPUT -o rmnet+ -p udp -j ACCEPT
iptables -tmangle -I OUTPUT -o rmnet+ -p udp -j MARK --set-mark 0x6688
iptables -tmangle -I OUTPUT -o rmnet+ -p udp --dport 53 -j ACCEPT
iptables -tmangle -I OUTPUT -o rmnet+ -p tcp -j ACCEPT

iptables -tmangle -I PREROUTING -i lo -p udp -j TPROXY --on-port 1088 --tproxy-mark 0x6688
iptables -t mangle -I PREROUTING -i lo -d 127/8 -j ACCEPT
iptables -t mangle -I PREROUTING -i lo -d 10/8 -j ACCEPT
iptables -t mangle -I PREROUTING -i lo -d 172.16/12 -j ACCEPT
iptables -t mangle -I PREROUTING -i lo -d 100.64/10 -j ACCEPT
iptables -t mangle -I PREROUTING -i lo -d 192.168/16 -j ACCEPT
iptables -t mangle -I PREROUTING -i lo -d 169.254/16 -j ACCEPT
iptables -t mangle -I PREROUTING -i lo -d 224/3 -j ACCEPT

iptables -tnat -I OUTPUT -o rmnet+ -p udp --dport 53 -j REDIRECT --to 1053
iptables -tnat -I OUTPUT -o rmnet+ -p tcp -m owner ! --uid-owner 3004 -j REDIRECT --to 1080

iptables -tnat -I PREROUTING -i rndis0 -p tcp ! -d 192.168.42/24 -j REDIRECT --to 1080
iptables -tnat -I PREROUTING -i rndis0 -p udp --dport 53  -j REDIRECT --to 1053
iptables -tnat -I PREROUTING -i wlan0 -p tcp ! -d 192.168.43/24 -j REDIRECT --to 1080
iptables -tnat -I PREROUTING -i wlan0 -p udp --dport 53  -j REDIRECT --to 1053
iptables -tmangle -P FORWARD DROP

ip rule add fwmark 0x6688 table 251
ip route add local 0.0.0.0/0 dev lo table 251

./bin/ss-local -a 3004 -c ./Tiny.conf --acl */Adblock-Bvc.acl >/dev/null &
./bin/pdnsd -c ./bin/pdnsd.conf >/dev/null &
./bin/gost -C ./core.ini >/dev/null &
./bin/redsocks2 -c ./bin/redsocks2.conf >/dev/null &

echo "  "
if [[ `ps|grep -i ss-local` != "" ]]
then
echo " ● 已启用 ss-local"
else
echo " ○ 已停用 ss-local"
fi
echo "  "
if [[ `ps|grep -i pdnsd` != "" ]]
then
echo " ● 已启用 pdnsd"
else
echo " ○ 已停用 pdnsd"
fi
echo "  "
if [[ `ps|grep -i gost` != "" ]]
then
echo " ● 已启用 gost"
else
echo " ○ 已停用 gost"
fi
echo "  "
if [[ `ps|grep -i redsocks2` != "" ]]
then
echo " ● 已启用 redsocks2"
else
echo " ○ 已停用 redsocks2"
fi