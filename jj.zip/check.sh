
for u in tiny;do
tiny_check=`ps | grep -i "[T]iny"`
if [[ $tiny_check != "" ]]
then  echo "¤核心检测 :  ✅ 已运行Tiny"
else echo "¤核心检测 :  ❌ 未运行Tiny";fi
echo "";done