pkill tiny
killall tiny
iptables -t mangle -P OUTPUT ACCEPT
iptables -t mangle -F OUTPUT
iptables -t mangle -P FORWARD ACCEPT
iptables -t mangle -F FORWARD
iptables -t nat -F OUTPUT
iptables -t nat -F PREROUTING
killall -9 tiny >/dev/null 2>&1
if [[ `ps|grep tiny|grep -v grep` != "" ]]
then  echo "¤核心检测 :  ✅ Tiny停止失败"
else echo "¤核心检测 :  ❌ 未运行Tiny";fi
case 1 in
0)  ;;
1) svc data disable;;
esac