
#################################################
cd "${0%/*}"
pkill tiny
killall tiny
./tiny -c ./Tiny.conf
. ./Tiny.conf
. ./core.ini
iptables -t mangle -P OUTPUT DROP
if [[ $IP != "" ]];then
for J in $IP;do
iptables -t mangle -I OUTPUT -p tcp -s $J/16 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT
iptables -t mangle -I OUTPUT -p udp -s $J/16 --dport 53 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT;done
else
iptables -t mangle -I OUTPUT -p tcp -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT
iptables -t mangle -I OUTPUT -p udp --dport 53 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT;fi
iptables -t mangle -I OUTPUT -o wlan+ -j ACCEPT
iptables -t mangle -I OUTPUT -o tun+ -j ACCEPT
iptables -t mangle -I OUTPUT -o lo -j ACCEPT
if [[ $DNS != "" ]];then
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-des $DNS
else
iptables -t nat -I OUTPUT -p udp --dport 53 -j REDIRECT --to $dns_listen_port;fi
iptables -t nat -I OUTPUT -p tcp -m owner ! --uid-owner $user$uid -j REDIRECT --to $listen_port
iptables -t nat -I OUTPUT -o wlan+ -j ACCEPT
iptables -t nat -I OUTPUT -o tun+ -j ACCEPT
iptables -t nat -I OUTPUT -o lo -j ACCEPT
iptables -t mangle -P FORWARD DROP
iptables -t nat -I PREROUTING -s 192.168/16 -p tcp ! -d 192.168/16 -j REDIRECT --to $listen_port
if [[ $UID1 != "" ]];then
for Z in $UID1;do
iptables -t mangle -I OUTPUT -m owner --uid-owner $Z -j DROP;done;fi
if [[ $UID3 != "" ]];then
for X in $UID3;do
iptables -t mangle -I OUTPUT -m owner --uid-owner $X -j ACCEPT;done;fi
if [[ $UID2 != "" ]];then
for C in $UID2;do
iptables -t mangle -I OUTPUT -m owner --uid-owner $J -j ACCEPT
iptables -t nat -I OUTPUT -m owner --uid-owner $C -j ACCEPT;done;fi
if [[ $GX != "" ]];then
iptables -t mangle -P FORWARD ACCEPT;fi
case 1 in
0)  ;;
1) svc data enable;;
esac

./check.sh