#!/system/bin/sh
DIR=/data/data/com.android.TyFlow/files
$DIR/tiny -k $DIR/tiny.pid
killall -9 tiny >/dev/null 2>&1
/data/data/com.android.TyFlow/files/tiny -c /data/data/com.android.TyFlow/files/Tiny.conf -p /data/data/com.android.TyFlow/files/tiny.pid
#以下为自定义脚本:
tiny_check=`ps | grep -i "[T]iny"`
if [[ $tiny_check != "" ]]
then  echo "¤核心检测 :  ✅ 已运行Tiny"
else echo "¤核心检测 :  ❌ 未运行Tiny";fi
